const express = require('express')
const ejs = require('ejs')
const bodyParser = require('body-parser')

const mongoose = require('mongoose')
const Student = require('./views/model/Student')

const app = express()
const PORT = 5000

mongoose.connect("mongodb://localhost:27017/studentDB")

app.set('view engine', 'ejs')
app.use(bodyParser.urlencoded({extended:true}))

app.get('/', async (req, res) => {

    const students = await Student.find()
    
    res.render('index', {students})

})

app.post('/save', async (req , res) => {

    const {rollNo, name, degree, city} = req.body

    const students = new Student({rollNo, name, degree, city})

    await students.save()

    res.redirect('/')
})

app.listen((PORT), () => {console.log(`Server run on Port : ${PORT}`)})
